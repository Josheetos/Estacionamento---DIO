#Projeto Estacionamento Typescript DIO

Para gerar o js a partir do ts, executar o seguinte comando na raiz do projeto:

npx -p typescript tsc
